# -*- coding: utf-8 -*-

import scrapy


class DoubanCrawlerItem(scrapy.Item):
    bookname = scrapy.Field()
    author = scrapy.Field()
    publisher = scrapy.Field()
    score = scrapy.Field()
    #page_num = scrapy.Field()
    #price = scrapy.Field()
    #publication_date = scrapy.Field()
    #isbn = scrapy.Field()
    rating_num = scrapy.Field()
    one_star = scrapy.Field()
    two_star = scrapy.Field()
    three_star = scrapy.Field()
    four_star = scrapy.Field()
    five_star = scrapy.Field()
    url = scrapy.Field()
    details = scrapy.Field()
