# -*- coding: utf-8 -*-
import scrapy
from douban_crawler.items import DoubanCrawlerItem
import re 

class DoubanSpider(scrapy.Spider):
    name = "douban"
    allowed_domains = ["book.douban.com"]
    start_urls = (
            'https://book.douban.com/top250?start=0',
    )

    def parse(self, response):
        for href in response.xpath('//div[@class="pl2"]/a/@href'):
            url = response.urljoin(href.extract())
            yield scrapy.Request(url,self.parse_dir_content)
        next_page = response.xpath('//span[@class="next"]/link/@href')
        if next_page:
            url = response.urljoin(next_page[0].extract())
            yield scrapy.Request(url,self.parse)
            

    def parse_dir_content(self,response):
        p=re.compile('\s+')
        details = re.sub(p,'',response.xpath('string(//div[@id="info"][1])').extract()[0])
       
        item = DoubanCrawlerItem()
        
        bookname = response.xpath('//h1/span[@property="v:itemreviewed"]/text()').extract()[0]
        author = response.xpath('//div[@id="info"]/span/a[contains(@href,"search")]/text()').extract()[0]
        publisher = response.xpath('//div[@id="info"]/text()').extract()[2]
        score = response.xpath('//div[@class="rating_self clearfix"]/strong/text()').extract()[0]
        rating_num = response.xpath('//div[@class="rating_sum"]/span/a/span/text()').extract()[0] 
        one_star = response.xpath('(//div[@class="rating_wrap clearbox"]/span[@class="rating_per"])[5]/text()').extract()[0]
        two_star = response.xpath('(//div[@class="rating_wrap clearbox"]/span[@class="rating_per"])[4]/text()').extract()[0]
        three_star = response.xpath('(//div[@class="rating_wrap clearbox"]/span[@class="rating_per"])[3]/text()').extract()[0]
        four_star = response.xpath('(//div[@class="rating_wrap clearbox"]/span[@class="rating_per"])[2]/text()').extract()[0]
        five_star = response.xpath('(//div[@class="rating_wrap clearbox"]/span[@class="rating_per"])[1]/text()').extract()[0]
        url = response.url
        '''
        if len(response.xpath('//div[@id="info"]/span/text()').extract()):
            page_num = response.xpath('//div[@id="info"]/text()').extract()[6]
            price = response.xpath('//div[@id="info"]/text()').extract()[8]
            publication_date = response.xpath('//div[@id="info"]/text()').extract()[4]
            isbn = response.xpath('//div[@id="info"]/text()').extract()[14]
        elif response.xpath('//div[@id="info"]/text()').extract()[10]:
            page_num = response.xpath('//div[@id="info"]/text()').extract()[6]
            price = response.xpath('//div[@id="info"]/text()').extract()[8]
            publication_date = response.xpath('//div[@id="info"]/text()').extract()[4]
            isbn = response.xpath('//div[@id="info"]/text()').extract()[14]
        elif response.xpath('//div[@id="info"]/text()').extract()[10]:
            page_num = response.xpath('//div[@id="info"]/text()').extract()[6]
            price = response.xpath('//div[@id="info"]/text()').extract()[8]
            publication_date = response.xpath('//div[@id="info"]/text()').extract()[4]
            isbn = response.xpath('//div[@id="info"]/text()').extract()[14]
        '''
             
        item['bookname']=bookname
        item['author'] = author
        item['publisher'] = publisher
        item['score'] = score
        #item['page_num'] = page_num
        #item['price'] = price
        #item['publication_date'] = publication_date
        #item['isbn'] = isbn
        item['rating_num'] = rating_num
        item['one_star'] = one_star
        item['two_star'] = two_star
        item['three_star'] = three_star
        item['four_star'] = four_star
        item['five_star'] = five_star
        item['url'] = url
        item['details'] = details

        yield item 




