#!/usr/bin/python
#-*-coding:utf-8-*-

import scrapy
from scrapy.spiders import Spider
from scrapy.selector import Selector
                              
from music_crawler.items import MusicCrawlerItem

class musicCrawler(Spider):
    name = "musiccrawler"
    allowed_domains = ["music.baidu.com","y.baidu.com",]
    start_urls = ["http://music.baidu.com/top/new/?pst=shouyeTop",]
	
    def parse(self,response):
        '''if response.xpath('//span[@title="此资源来自百度音乐人"]/@class').extract()[0].encode('utf-8') == u'i-musician'.encode("utf-8") :
                parse_dir_contents_sp(self,response)
        '''
        for href in response.xpath('//span[@class="song-title "]/a[@data-film="null"]/@href'):			
            if not href.extract().startswith('/mv'):
			    	url = response.urljoin(href.extract())
            yield scrapy.Request(url,self.parse_dir_contents)
    
    def parse_dir_contents(self,response):
        item = MusicCrawlerItem()
        songname = response.xpath('//div[@class="song"]/h2/span[@class="name"]/text()').extract()[0]
        singer = response.xpath('//div[@class="info-holder clearfix"]/ul/li/span[@class="author_list"]/@title').extract()[0]
        hot = response.xpath('//div[@class="song"]/span[@class="song-play-num hot-num"]/span[@class="num"]/text()').extract()[0] 

        item['songname'] = songname
        item['singer'] = singer
        item['hot'] = hot
		
        yield item

    def parse_dir_contents_sp(self,response):
        item = MusicCrawlerItem()
        songname = response.xpath('//span[@class="song-title "]/a/text()').extract()[0]
        singer = response.xpath('//span[@class="author_list"]/a/text()').extract()[0]
        hot = 0

        item['songname'] = songname
        item['singer'] = singer
        item['hot'] = hot
        
        yield item









