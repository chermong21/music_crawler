# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


class MusicCrawlerPipeline(object):
    def process_item(self, item, spider):
        '''print item['name'] +item['writer']+item['score']+item['ISBN']'''
        info = u'----'.join([item['songname'], item['singer'], item['hot'], u"\n"])
        info = info.encode('utf-8')
        f=open('/Users/Emily/workspace/scrapy/music_crawler/musicinfo.txt','a')
        f.write(info)
        f.close()
        return item
